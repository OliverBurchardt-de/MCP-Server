# FinRobotics DATEV MCP Server

Ein lokaler MCP Server für DATEV Buchungsdaten im EXTF-Format.
Er richtet sich an Steuerberater, Buchhalter und Finance-Teams, die DATEV-Daten per natürlicher Sprache auswerten wollen.
Statt Exportdateien manuell zu durchsuchen, können Sie Fragen stellen und erhalten direkt Antworten zu Salden, offenen Posten und einzelnen Buchungen.

## Beispiel aus der Praxis

**Steuerberater:** Welche Kunden schulden uns noch Geld?
**Assistent:** In den geladenen DATEV-Daten sind 14 offene Debitorenposten. Die höchsten offenen Beträge haben Müller GmbH mit 12.480 EUR und Schneider OHG mit 8.950 EUR.

**Steuerberater:** Wie hoch sind die Bewirtungskosten in Q1?
**Assistent:** Im Zeitraum Januar bis März wurden 4.320 EUR auf Bewirtung gebucht. Die meisten Buchungen liegen im Februar.

**Steuerberater:** Suche nach Rechnung RE-2026-0089.
**Assistent:** Ich habe 2 passende Buchungen gefunden. Eine Ausgangsrechnung vom 12.02.2026 und einen zugehörigen Zahlungseingang vom 03.03.2026.

**Steuerberater:** Wie ist der Kontostand auf dem Girokonto?
**Assistent:** Das Konto 1200 hat im geladenen Buchungsstapel aktuell einen Saldo von 48.270 EUR.

## Warum ein MCP Server für DATEV?

DATEV ist für viele Kanzleien in Deutschland der Standard.
Ohne Zugriff auf Mandantendaten können KI-Tools keine sinnvollen Auskünfte geben.
Dieser MCP Server ist die Brücke zwischen DATEV-Export und KI-Assistent.
Er arbeitet lokal auf Ihrem Rechner.
Die Daten bleiben in Ihrer Umgebung.
Für Phase 1 ist kein DATEV-Partnerprogramm nötig.
Die Anbindung funktioniert rein dateibasiert über EXTF-Exporte.
So wird aus einem Buchungsstapel ein direkt befragbarer Datenbestand.

## Features

- EXTF-Parser für DATEV CSV-Dateien mit `;` als Delimiter
- ISO-8859-1 und Windows-1252 kompatibles Decoding inklusive Umlaute
- In-Memory-Datenhaltung ohne persistente Datenbank
- 5 MCP Tools für DATEV-Auswertungen
- TypeScript strict mode, ESLint, Prettier, Vitest

Verfügbare Tools:

- `load_datev_file`
- `get_account_balance`
- `get_open_items`
- `list_bookings`
- `search_documents`

## Schnellstart: In 3 Schritten zum sprechenden Buchungsstapel

### Schritt 1: DATEV-Export erstellen

Erstellen Sie in DATEV einen Export über:

`Datei -> Export -> Buchungsdaten -> DATEV-Format (EXTF)`

Unterstützt werden in Phase 1 Exporte aus:

- DATEV Kanzlei-Rechnungswesen
- DATEV Pro
- DATEV Unternehmen Online

Der Export enthält den Buchungsstapel mit allen Buchungen im gewählten Zeitraum.
Die Datei liegt typischerweise im DATEV Belegarchiv oder auf dem Desktop, je nach gewähltem Exportziel.

### Schritt 2: MCP Server konfigurieren

#### Claude Desktop Config

```json
{
  "mcpServers": {
    "datev": {
      "command": "npx",
      "args": ["datev-mcp-server"]
    }
  }
}
```

Für lokale Entwicklung stattdessen:

```json
{
  "mcpServers": {
    "datev": {
      "command": "node",
      "args": ["/absolute/path/to/datev-mcp-server/dist/index.js"]
    }
  }
}
```

#### Cursor Config

```json
{
  "mcpServers": {
    "datev": {
      "command": "npx",
      "args": ["datev-mcp-server"]
    }
  }
}
```

Auch in Cursor können Sie für lokale Entwicklung direkt auf die gebaute `dist/index.js` zeigen.

#### ChatGPT Config

ChatGPT unterstützt aktuell noch keinen MCP-Server im gleichen lokalen Desktop-Workflow wie Claude Desktop oder Cursor.
Sobald MCP-Support verfügbar ist, kann diese Konfiguration ergänzt werden.

### Schritt 3: Fragen stellen

Nach dem Start laden Sie zuerst Ihre EXTF-Datei und stellen dann fachliche Fragen in natürlicher Sprache.

Beispiel-Queries:

- „Lade die DATEV-Datei `/Pfad/zum/export.extf`“
- „Welche Kunden schulden uns noch Geld?“
- „Wie hoch sind die Bewirtungskosten in Q1?“
- „Zeig mir alle Buchungen über 1.000 EUR im Februar“
- „Suche nach Rechnung RE-2026-0089“
- „Wie ist der Kontostand auf dem Girokonto?“
- „Kann Müller GmbH die nächste Steuervorauszahlung stemmen?“

## Installation

### Mit `npx`

```bash
npx datev-mcp-server
```

### Global via npm

```bash
npm install -g datev-mcp-server
datev-mcp-server
```

### Lokal für Entwicklung

```bash
npm install
npm run build
npm test
npm run dev
```

## Sicherheit & Datenschutz

- Alle Daten bleiben lokal im laufenden Prozessspeicher
- Kein Cloud-Upload
- Kein DATEV-Login nötig
- Kein Internetzugang nötig, der MCP Server läuft offline
- DSGVO-konform nutzbar, weil Daten den Rechner nicht verlassen
- Open Source, jede relevante Codezeile ist einsehbar

## MCP Tools

### `load_datev_file`
Lädt eine EXTF-Datei von der lokalen Festplatte, liest Header und Buchungszeilen ein und hält die Daten im Prozessspeicher.

### `get_account_balance`
Berechnet den Saldo eines Kontos als Summe Soll minus Haben, inklusive Anzahl Buchungen und letztem Buchungstag.

### `get_open_items`
Findet offene Debitoren- und Kreditorenposten anhand von Personenkonten und Fälligkeitsdaten. Optional filterbar nach Typ und Überfälligkeit.

### `list_bookings`
Filtert Buchungen nach Konto, Zeitraum, Mindestbetrag und Volltext im Buchungstext oder in den Belegfeldern.

### `search_documents`
Durchsucht Buchungstext, `Belegfeld1` und `Belegfeld2` nach einem Suchbegriff und gibt Treffer mit Kontext zurück.

## Roadmap

- Phase 1 ✅: EXTF File Parser und lokale Analyse von Buchungsstapeln
- Phase 2: DATEV Online API Integration mit Live-Daten ohne manuellen Export
- Phase 3: Schreib-Operationen, zum Beispiel Buchungsvorschläge zurück in DATEV

## Development

```bash
npm install
npm run lint
npm run build
npm test
```

## Für Entwickler

### DATEV EXTF Format

DATEV EXTF-Dateien sind strukturierte Exporte mit Metadaten und Buchungszeilen.
Für diesen Server sind vor allem folgende Eigenschaften relevant:

- Encoding: ISO-8859-1 oder Windows-1252
- Delimiter: `;`
- Zeile 1 und 2 enthalten Header-Felder und Header-Werte
- Zeile 3 enthält die Spaltenüberschriften der Buchungen
- Ab Zeile 4 folgen die Buchungsdaten

Mehr zur DATEV-Spezifikation:
https://developer.datev.de/datev/platform/de/dtvf

## Contributing

Contributions are welcome. Please open an issue or pull request with a clear description, tests where appropriate, and a focus on practical DATEV workflows.

## English Summary

This project provides a local MCP server for DATEV EXTF exports.
It is built for German tax advisors, accountants, and finance teams who want to query bookkeeping data in natural language.
The server reads DATEV export files locally and exposes tools for balances, open items, booking search, and document lookup.
No DATEV login is required in Phase 1.
No data leaves the machine.
The current version focuses on file-based workflows and local analysis.

## License

MIT

## FinRobotics

Mehr zu FinRobotics: https://finrobotics.de
